<!-- code to check user weight and display food recommendation based on weight range
 25-30: RIce and fish
 30-45: boiled yam
 45-60: amala and ogunfe
 61-70: egg, cereal, milk
 71-90: beans, moinmoin, watermelon
 90 and above: vineless seed grape -->
<html>
<head>
    <title>Weight Qualification Form</title>
</head>
<body>
    <h1>Weight Qualification Form</h1>
    <form action="check_weight.php" method="post">
        <label for="weight">Enter your weight (kg):</label>
        <input type="number" name="weight" id="weight" step="0.1" min="0" required>
        <br><br>
        <input type="submit" value="Check Recommendation">
    </form>
        
</body>
</html>