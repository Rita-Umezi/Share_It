<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $weight = $_POST["weight"];

    if ($weight >= 25 && $weight <= 30) {
        echo "Recommended food: Rice and fish";
    } elseif ($weight > 30 && $weight <= 45) {
        echo "Recommended food: Boiled yam";
    } elseif ($weight > 45 && $weight <= 60) {
        echo "Recommended food: Amala and ogunfe";
    } elseif ($weight > 60 && $weight <= 70) {
        echo "Recommended food: Egg, cereal, milk";
    } elseif ($weight > 70 && $weight <= 90) {
        echo "Recommended food: Beans, moinmoin, watermelon";
    } else {
        echo "Recommended food: Vineless seed grape";
    }
}
?>
